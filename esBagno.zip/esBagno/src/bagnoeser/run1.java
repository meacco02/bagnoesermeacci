/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bagnoeser;

/**
 *
 * @author meaccifederico
 */
public class run1 implements Runnable {
    
    public void run(){
        n1Bagno p1= new n1Bagno();
        p1.stampaUomo();
    }
    
    
    
}
