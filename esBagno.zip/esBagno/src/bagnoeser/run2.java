/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bagnoeser;

/**
 *
 * @author meaccifederico
 */
public class run2 implements Runnable {
    public void run(){
        n2Bagno p2= new n2Bagno();
        p2.stampaDonna();
    }
    
    
}
